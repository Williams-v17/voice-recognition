/* ═══════════════════════════════════════════════════════════════
   demo-backend.js — runs the "backend" inside the browser so the
   site works on GitHub Pages (static hosting, no Python server).
   Intercepts fetch('/api/...') and answers from localStorage +
   an in-browser voiceprint (MFCC) extractor.
   ═══════════════════════════════════════════════════════════════ */
(function () {
  const LS = {
    users: 'vas_users', tok: 'vas_tokens',
  };
  const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
  const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));
  const json = (obj, status = 200) =>
    new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } });
  const err = (status, detail) => json({ detail }, status);
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  async function sha256(text) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /* ── Voiceprint extraction (MFCC mean+std, 16 kHz) ───────────── */
  const SR = 16000, N_FFT = 512, HOP = 160, WIN = 400, N_MEL = 40, N_MFCC = 20;

  function fft(re, im) {
    const n = re.length;
    for (let i = 1, j = 0; i < n; i++) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const ang = -2 * Math.PI / len, wr = Math.cos(ang), wi = Math.sin(ang);
      for (let i = 0; i < n; i += len) {
        let cr = 1, ci = 0;
        for (let k = 0; k < len / 2; k++) {
          const a = i + k, b = i + k + len / 2;
          const tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
          re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
          const nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
        }
      }
    }
  }

  const hz2mel = (f) => 2595 * Math.log10(1 + f / 700);
  const mel2hz = (m) => 700 * (Math.pow(10, m / 2595) - 1);
  let _fb = null;
  function melBank() {
    if (_fb) return _fb;
    const bins = N_FFT / 2 + 1;
    const pts = [];
    const lo = hz2mel(60), hi = hz2mel(SR / 2);
    for (let i = 0; i < N_MEL + 2; i++) pts.push(mel2hz(lo + (hi - lo) * i / (N_MEL + 1)));
    const idx = pts.map(f => Math.floor((N_FFT + 1) * f / SR));
    _fb = [];
    for (let m = 1; m <= N_MEL; m++) {
      const row = new Float32Array(bins);
      for (let k = idx[m - 1]; k < idx[m]; k++) row[k] = (k - idx[m - 1]) / Math.max(1, idx[m] - idx[m - 1]);
      for (let k = idx[m]; k < idx[m + 1]; k++) row[k] = (idx[m + 1] - k) / Math.max(1, idx[m + 1] - idx[m]);
      _fb.push(row);
    }
    return _fb;
  }

  function extractFeatures(samples) {
    // trim silence (simple energy gate)
    let peak = 0; for (let i = 0; i < samples.length; i++) peak = Math.max(peak, Math.abs(samples[i]));
    if (peak < 1e-4) return null;
    const fb = melBank();
    const win = new Float32Array(WIN);
    for (let i = 0; i < WIN; i++) win[i] = 0.54 - 0.46 * Math.cos(2 * Math.PI * i / (WIN - 1));
    const frames = [];
    const energies = [];
    for (let s = 0; s + WIN <= samples.length; s += HOP) {
      const re = new Float32Array(N_FFT), im = new Float32Array(N_FFT);
      let e = 0;
      for (let i = 0; i < WIN; i++) { const v = (samples[s + i] - (i ? samples[s + i - 1] * 0.97 : 0)) * win[i]; re[i] = v; e += v * v; }
      fft(re, im);
      const mel = new Float32Array(N_MEL);
      for (let m = 0; m < N_MEL; m++) {
        let acc = 0; const row = fb[m];
        for (let k = 0; k <= N_FFT / 2; k++) if (row[k]) acc += row[k] * (re[k] * re[k] + im[k] * im[k]);
        mel[m] = Math.log(acc + 1e-10);
      }
      frames.push(mel); energies.push(e);
    }
    if (frames.length < 20) return null;
    const sorted = [...energies].sort((a, b) => a - b);
    const gate = sorted[Math.floor(sorted.length * 0.4)];
    const voiced = frames.filter((_, i) => energies[i] > gate);
    if (voiced.length < 15) return null;
    // DCT -> MFCC
    const mf = voiced.map(mel => {
      const c = new Float32Array(N_MFCC);
      for (let k = 0; k < N_MFCC; k++) {
        let s = 0; for (let m = 0; m < N_MEL; m++) s += mel[m] * Math.cos(Math.PI * k * (m + 0.5) / N_MEL);
        c[k] = s;
      }
      return c;
    });
    const mean = new Float32Array(N_MFCC), sd = new Float32Array(N_MFCC);
    mf.forEach(c => c.forEach((v, k) => mean[k] += v / mf.length));
    mf.forEach(c => c.forEach((v, k) => sd[k] += (v - mean[k]) ** 2 / mf.length));
    // drop c0 (loudness); keep c1..c19 mean + std
    return [...mean.slice(1), ...[...sd].slice(1).map(Math.sqrt)];
  }

  async function blobToFeatures(blob) {
    const AC = window.AudioContext || window.webkitAudioContext;
    const ctx = new AC({ sampleRate: SR });
    try {
      const buf = await ctx.decodeAudioData(await blob.arrayBuffer());
      return extractFeatures(buf.getChannelData(0));
    } finally { ctx.close && ctx.close(); }
  }

  const dist = (a, b) => Math.sqrt(a.reduce((s, v, i) => s + (v - b[i]) ** 2, 0));
  const norm = (a) => Math.sqrt(a.reduce((s, v) => s + v * v, 0));
  const cosine = (a, b) => a.reduce((s, v, i) => s + v * b[i], 0) / (norm(a) * norm(b) + 1e-9);

  /* ── Auth helpers ───────────────────────────────────────────── */
  function emailFromReq(init) {
    const h = (init && init.headers) || {};
    const auth = h.Authorization || h.authorization || '';
    const t = auth.replace('Bearer ', '');
    return read(LS.tok, {})[t] || null;
  }
  function issueToken(email) {
    const t = crypto.randomUUID();
    const all = read(LS.tok, {}); all[t] = email; write(LS.tok, all);
    return t;
  }

  /* ── Route handlers ─────────────────────────────────────────── */
  async function route(path, init) {
    const method = ((init && init.method) || 'GET').toUpperCase();
    const fd = init && init.body instanceof FormData ? init.body : null;
    const users = read(LS.users, {});

    if (path === '/api/health') return json({ status: 'ok', service: 'Voice Authentication System (browser demo)' });

    if (path === '/api/register' && method === 'POST') {
      const name = (fd.get('name') || '').trim(), email = (fd.get('email') || '').trim().toLowerCase(), pw = fd.get('password') || '';
      if (!name) return err(400, 'Name is required');
      if (!email.includes('@') || !email.includes('.')) return err(400, 'Invalid email address');
      if (pw.length < 8) return err(400, 'Password must be at least 8 characters');
      if (users[email]) return err(409, 'Email already registered. Please log in.');
      users[email] = { name, email, username: name.toLowerCase().replace(/\s+/g, '_'), pw: await sha256(pw), voiceprint: null };
      write(LS.users, users);
      return json({ status: 'ok', message: 'Account created', username: users[email].username, access_token: issueToken(email), token_type: 'bearer' });
    }

    if (path === '/api/login' && method === 'POST') {
      const email = (fd.get('email') || '').trim().toLowerCase();
      const u = users[email];
      if (!u || u.pw !== await sha256(fd.get('password') || '')) return err(401, 'Invalid email or password');
      return json({ status: 'ok', name: u.name, email: u.email, username: u.username, whl_ready: !!u.voiceprint, access_token: issueToken(email), token_type: 'bearer' });
    }

    const email = emailFromReq(init);
    if (!email || !users[email]) return err(401, 'Please log in again.');
    const user = users[email];

    if (path === '/api/process' && method === 'POST') {
      const files = fd.getAll('files');
      if (files.length < 5 || files.length > 20) return err(400, 'Please provide between 5 and 20 audio files.');
      const feats = []; let skipped = 0;
      for (const f of files) {
        try { const v = await blobToFeatures(f); v ? feats.push(v) : skipped++; } catch { skipped++; }
      }
      if (feats.length < 3) return err(400, 'Could not read enough usable audio. Record in a quieter place and speak for a few seconds each.');
      const dim = feats[0].length;
      const mean = new Array(dim).fill(0);
      feats.forEach(v => v.forEach((x, i) => mean[i] += x / feats.length));
      const spread = feats.reduce((s, v) => s + dist(v, mean), 0) / feats.length; // how much your own takes vary
      user.voiceprint = { mean, spread, samples: feats.length, created: new Date().toISOString() };
      write(LS.users, users);
      await sleep(1500);
      return json({ status: 'ok', message: 'Voiceprint created', build_id: crypto.randomUUID().slice(0, 8), accepted_files: feats.length, skipped_files: skipped });
    }

    if (path === '/api/process_company' && method === 'POST') {
      const n = fd.getAll('files').length;
      user.voiceprint = user.voiceprint || { company: true, samples: n, created: new Date().toISOString(), mean: null };
      user.company = { files: n };
      write(LS.users, users);
      await sleep(1500);
      return json({ status: 'ok', message: `Received ${n} files (demo mode: company packaging is simulated).` });
    }

    if (path === '/api/status') {
      const ready = !!user.voiceprint;
      return json({ status: 'ok', whl_ready: ready, name: user.name, email, whl_filename: ready ? 'voiceprint.json' : null });
    }

    if (path === '/api/download') {
      if (!user.voiceprint) return err(404, 'Complete voice registration first.');
      const out = { note: 'Browser-demo voiceprint. Not a real .whl package.', user: user.username, ...user.voiceprint };
      return new Response(new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' }), { status: 200 });
    }

    if (path === '/api/verify' && method === 'POST') {
      if (!user.voiceprint || !user.voiceprint.mean) return err(404, 'No voiceprint found. Register your voice first.');
      const f = fd.get('file');
      let v;
      try { v = await blobToFeatures(f); } catch { return err(400, 'Could not read that audio file.'); }
      if (!v) return err(400, 'Audio too quiet or too short. Speak for a few seconds.');
      const ref = user.voiceprint.mean;
      const cos = cosine(v, ref);
      // distance relative to how much the user's own takes vary
      const ratio = dist(v, ref) / Math.max(user.voiceprint.spread, 1e-6);
      const conf = Math.round(Math.max(0, Math.min(100, 100 - Math.max(0, ratio - 0.8) * 35)) * 10) / 10;
      let label, matched, color, icon;
      if (conf >= 85) [label, matched, color, icon] = ['Strong Match', true, 'green', 'fa-check-circle'];
      else if (conf >= 70) [label, matched, color, icon] = ['Good Match', true, 'amber', 'fa-check-circle'];
      else if (conf >= 50) [label, matched, color, icon] = ['Borderline', false, 'orange', 'fa-circle-exclamation'];
      else [label, matched, color, icon] = ['No Match', false, 'red', 'fa-xmark-circle'];
      await sleep(900);
      return json({ status: 'ok', confidence: conf, cosine_score: Math.round(cos * 10000) / 10000, label, matched, color, icon });
    }

    return err(404, 'Not found');
  }

  const realFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : input.url;
    let path = null;
    try { path = new URL(url, location.href).pathname; } catch { }
    const i = path ? path.indexOf('/api/') : -1;
    if (i !== -1) return route(path.slice(i), init).catch(e => err(500, String(e && e.message || e)));
    return realFetch(input, init);
  };
  window.__VAS_DEMO__ = true;
})();
